const Footer = () => {
    return (
      <header>
          <div className="footer"><p id="footer">My Zoo developed by Josh Mundy, Chelsea Villard, and Syeda Ahmed</p></div>
      </header>
    )
  }
  
  export default Footer